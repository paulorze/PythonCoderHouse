#Crear el archivo setup.py para el paquete:

from setuptools import setup, find_packages

setup(

    name="Entrega #2",
    version="1.0",
    author="Entrega #2",
    description="Paquete para 2da entrega del curso Python Flex de CoderHouse",
    author_email="rzeszutagustin@gmail.com",
    packages=["package"]

)